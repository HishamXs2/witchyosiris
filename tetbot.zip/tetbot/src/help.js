const help = (prefix) => { 
	return `                 
┏━━°❀ ❬ *GODDESS ISIS BOT* ❭ ❀°━━┓
┃
┣➥ *${prefix}info*
┣➥ *${prefix}owner*
┃
┣━━━━°❀ ❬ *COMMANDS* ❭ ❀°━━━━━⊱
┃
┣➥ *${prefix}tts en* <text>
┣➥ *${prefix}sticker*
┣➥ *${prefix}lyrics*
┣➥ *${prefix}map*
┣➥ *${prefix}hidetag*
┣➥ *${prefix}hidetag2*
┣➥ *${prefix}hidetag3*
┃
┣━━━━━°❀ ❬ *Contact me* ❭ ❀°━━━━━⊱
┃
┣➥ *Instagram = https://instagram.com/witchy_osiris*
┣➥ *wa.me/+919061293478*
┃
┣━━━━━━━━━━━━━━━━━━━━
┃ *${prefix}POWERED BY @Witchy Osiris*
┗━━━━━━━━━━━━━━━━━━━━`
}
exports.help = help
